
library(ggplot2)
library(dplyr)
library(readr)
library(corrplot)
library(GGally)
# Read the dataset
data <- read.csv("D:/cancer_dataset/diabetes_012_health_indicators_BRFSS2015.csv")

# Step 1: Preprocess the Data

# Assuming your dataset is stored in the 'data' variable

# Convert non-numeric variables to suitable representations
data$Sex <- as.factor(data$Sex)
data$Education <- as.factor(data$Education)

# Handle missing values if necessary
# For example, if you want to remove rows with missing values
data <- na.omit(data)


# Step 2: Feature Selection

# Perform correlation analysis with numeric variables
numeric_cols <- sapply(data, is.numeric)
numeric_data <- data[, numeric_cols]
cor_with_diabetes <- sapply(numeric_data, function(x) cor(x, data$Diabetes_012))
selected_numeric_features <- names(cor_with_diabetes[abs(cor_with_diabetes) > 0.2])

# Convert non-numeric variables to dummy variables
dummy_data <- model.matrix(~ Sex + Education - 1, data = data)
selected_nonnumeric_features <- colnames(dummy_data)

# Combine selected numeric and non-numeric features
selected_features <- c(selected_numeric_features, selected_nonnumeric_features)

# Step 3: Build Logistic Regression Model

# Prepare the dataset with selected features
selected_features <- c("Diabetes_012", selected_features)  # Include the target variable
dataset <- data[, selected_features]

# Fit logistic regression model
logit_model <- glm(Diabetes_012 ~ ., data = dataset, family = binomial)

# Print the model summary
summary(logit_model)

# Step 4: Interpretation

# Extract feature importance (odds ratios) and p-values
feature_importance <- summary(logit_model)$coefficients[-1, c("Estimate", "Pr(>|z|)")]

# Print the selected features and their importance
cat("Selected Features and their Importance:\n")
print(feature_importance)
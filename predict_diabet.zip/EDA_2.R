
library(data.table)
library(ggplot2)

d <- read.csv("D:/cancer_dataset/diabetes_012_health_indicators_BRFSS2015.csv")


d$Diabetes_012 = as.factor(d$Diabetes_012)

ggplot(d, aes(BMI, fill = Diabetes_012))+
  geom_histogram(alpha = .75)+
  facet_grid(Diabetes_012 ~ ., scales = 'free_y')

ggplot(d, aes(Age, group = Diabetes_012, color = Diabetes_012))+
  geom_boxplot(alpha = .75)

d$one = 1
ds = d[, .(n = sum(one)), .(Diabetes_012, NoDocbcCost)]
ds[, n_total := sum(n), .(NoDocbcCost)]
ds[, n_percent := n / n_total]

ggplot(ds, aes(as.factor(NoDocbcCost), n_percent, fill = Diabetes_012))+
  geom_bar(stat = 'identity', )

# Sex

d$one = 1
ds = d[, .(n = sum(one)), .(Diabetes_012, Sex)]
ds[, n_total := sum(n), .(Sex)]
ds[, n_percent := n / n_total]

ggplot(ds, 
       aes(as.factor(Sex), n_percent, fill = Diabetes_012))+
  geom_bar(stat = 'identity', )

########
setwd("D:/regression_project")

Sys.setlocale(locale = 'persian')

library(data.table)
library(ggplot2)

d = fread('iranprovs_mortality_monthly.csv', encoding = 'UTF-8')
age = fread('provinces_age.csv' , encoding = 'UTF-8')

d$ym_num = d$y + d$m / 12 - 1/24


#####
#last_part
#to see which province acts better against covid
#####
df_death_population_kid = d[, .(n = sum(n)), .(y, m, ym_num, age_group <= 15 , prov)]
df_death_population_kid = df_death_population_kid[age_group == TRUE]
df_death_population_kid = df_death_population_kid[,-4]
df_death_population_kid$age_group <- "0 - 15"

df_death_population_work = d[, .(n = sum(n)), .(y, m, ym_num, age_group < 45 , age_group >15 , prov)]
df_death_population_work = df_death_population_work[age_group == TRUE & age_group.1 == TRUE]
df_death_population_work <- df_death_population_work[,-4:-5]
df_death_population_work$age_group <- "15-45"

df_death_population_old = d[, .(n = sum(n)), .(y, m, ym_num, age_group >= 45 , prov)]
df_death_population_old = df_death_population_old[age_group == TRUE]
df_death_population_old <- df_death_population_old[,-4]
df_death_population_old$age_group <- "older than 45"

######
ds = df_death_population_old[, .(n = sum(n)), .(y, m, ym_num)]

ggplot(ds, aes(ym_num, n))+
  geom_line()+
  geom_point()+
  scale_x_continuous(breaks = 1389:1401)+
  scale_y_continuous(limits = c(0, 71000))+
  geom_vline(xintercept = 1398 + 11/12 -1/24, linetype = 'dashed')

d <- df_death_population_old

######
###################
ym_num_covid = 1398 + 11/12 - 1/24
df_prov = d[ym_num > ym_num_covid]
df_prov_per_month = df_prov[, .(n = sum(n)), .(y, m, ym_num, prov)]
df_prov_per_month$covid_death <- 0
df_prov = df_prov[, .(n = sum(n)), .(prov)]
df_prov$covid_death <- 0
ds_temp = d[, .(n = sum(n)), .(y, m, ym_num, prov)]
ds_temp$covid
for (prove_num in 1:length(unique(ds_temp$prov))){
  all_death = 0
  covid_death = 0
  for (month_num in 1:12){
    PROV = unique(ds_temp$prov)[prove_num]
    dsm = ds_temp[prov == PROV & m == month_num,]
    ym_num_covid = 1398 + 11/12 - 1/24
    # to avoid dealing with non-linear patterns we only look at the last 5 years
    ym_num_start = ym_num_covid - 6
    dsm = dsm[ym_num > ym_num_start]
    
    dsm2fit = dsm[ym_num < ym_num_covid - 1]
    
    fit = lm(n ~ ym_num, dsm2fit)
    #summary(fit)
    
    dsm$n_predicted = predict(fit ,dsm)
    predict_df = dsm[ym_num > ym_num_covid]
    #print(summary(fit))
    values <- summary(fit)$fstatistic
    model_pval <- pf(values[1], values[2], values[3], lower.tail = FALSE)
    #check if p_value is more than 0.2 then we use mean and std
    #for finding outliers and we ignore linear regression
    if (model_pval > 0.2){
      model_svd = sd(dsm2fit$n)
      model_mean = mean(dsm2fit$n)
      
      predict_df = predict_df[n > model_mean + (2*model_svd)]
      predict_df$covid_death <- predict_df$n - model_mean
      
      df_prov_per_month$covid_death <- ifelse(df_prov_per_month$ym_num %in% predict_df$ym_num & df_prov_per_month$prov %in% predict_df$prov,
                                              predict_df$covid_death[match(paste(df_prov_per_month$ym_num, df_prov_per_month$prov), paste(predict_df$ym_num, predict_df$prov))],
                                              df_prov_per_month$covid_death)
      
      temp_df = predict_df[, .(n_covid = sum(covid_death) , n_all = sum(n)),]
      all_death = all_death + temp_df$n_all
      
      covid_death = covid_death + temp_df$n_covid
      
    }else{
      predict_df$covid_death <- predict_df$n - predict_df$n_predicted
      df_prov_per_month$covid_death <- ifelse(df_prov_per_month$ym_num %in% predict_df$ym_num & df_prov_per_month$prov %in% predict_df$prov,
                                              predict_df$covid_death[match(paste(df_prov_per_month$ym_num, df_prov_per_month$prov), paste(predict_df$ym_num, predict_df$prov))],
                                              df_prov_per_month$covid_death)
      temp_df = predict_df[, .(n_covid = sum(covid_death) , n_all = sum(n)),]
      all_death = all_death + temp_df$n_all
      if (temp_df$n_covid > 0){
        covid_death = covid_death + temp_df$n_covid
      }else{
        
      }
    }
    
    ggplot(dsm)+
      geom_smooth(aes(ym_num, n_predicted), method = 'lm')+
      geom_point(aes(ym_num, n), size = 3)+
      scale_x_continuous(breaks = 1389:1401)+
      geom_vline(xintercept = 1398 + 11/12 -1/24, linetype = 'dashed')+
      ggtitle(label = PROV, subtitle = paste('month: ', month_num))
    
  }
  df_prov[prove_num]$covid_death <- covid_death
}
df_prov_per_month$covid_death <- ifelse(df_prov_per_month$covid_death < 0, 0,df_prov_per_month$covid_death)
df_prov_per_month$covid_death <- ifelse(df_prov_per_month$covid_death > df_prov_per_month$n, df_prov_per_month$n,df_prov_per_month$covid_death)


df_prov$covid_percentage = df_prov$covid_death / df_prov$n
df_prov_per_month$covid_percentage = df_prov_per_month$covid_death / df_prov_per_month$n

df_prov <- merge(df_prov , age, by="prov")

# Create the heatmap
ggplot(df_prov_per_month, aes(x = prov, y = ym_num, fill = covid_percentage)) +
  geom_tile(color = "white") +
  scale_fill_gradient(low = "#FFE5B4", high = "#8b0000") +
  labs(title = "Heatmap of COVID-19 Percentage by Province and Year-Month",
       x = "Province",
       y = "Year-Month",
       fill = "COVID-19 Percentage") +
  theme(axis.text.x = element_text(angle = 90, hjust = 1),
        plot.title = element_text(hjust = 0.5))


df_high_covid = df_prov_per_month[covid_percentage > 0.35]

df_all_death = df_prov[, .(all_death_covid = sum(covid_death)),]

df_prov <- setorder(df_prov,covid_percentage)


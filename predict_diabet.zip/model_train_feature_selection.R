library(data.table)
library(ggplot2)
library(e1071)  # For Naive Bayes classifier
library(class)  # For K-nearest neighbors classifier
library(glmnet)  # For logistic regression
library(nnet)  # For multinomial logistic regression
library(randomForest)  # For random forest classifier

# Read the dataset
d <- read.csv("D:/cancer_dataset/diabetes_binary_5050split_health_indicators_BRFSS2015.csv")

N <- 20000
d <- d[sample(1:nrow(d), size = N),]

# Convert factor columns to numeric
factor_cols <- c("Sex", "Education")
d[, factor_cols] <- lapply(d[, factor_cols], as.numeric)

# Preprocess the data
ds <- data.table(sapply(d, function(x) (x - min(x)) / (max(x) - min(x))), keep.rownames = TRUE)

train <- 0.7
test <- 0.2
validate <- 0.1
# Select numeric columns
numeric_cols <- sapply(d, is.numeric)
numeric_data <- d[, numeric_cols]
target_variable <- "Diabetes_binary"  # Replace with the correct column name
target_class <- class(d[[target_variable]])
print(target_class)

# Calculate correlation coefficients
correlation <- cor(numeric_data[, -ncol(numeric_data)])

# Sort the correlation values with the Diabetes_binary feature in descending order
cor_with_target <- sort(correlation[,"Diabetes_binary"], decreasing = TRUE)

# Choose the top correlated features
top_features <- names(cor_with_target)[2:8]
selected_features = top_features# Select the top 5 features (adjust as needed)
print(top_features)
# Perform feature selection using random forest variable importance

ctrl <- rfeControl(functions = rfFuncs, method = "cv", number = 10)  # Change the number of features as needed

# Perform feature selection using random forest
rf_profile <- rfe(d[, -ncol(d)], d$Diabetes_binary, sizes = 1:(ncol(d) - 1), rfeControl = ctrl)

# Get the selected features
selected_features <- names(rf_profile$optVariables)
print(selected_features)


d$Diabetes_binary <- as.factor(d$Diabetes_binary)

# Split the data into train, test, and validation sets
set.seed(123)  # For reproducibility
indices <- sample(nrow(ds))  # Randomly shuffle the row indices
n_train <- round(train * nrow(ds))
n_test <- round(test * nrow(ds))
n_validate <- round(validate * nrow(ds))

d_tn <- ds[indices[1:n_train], ]  # Training set
d_remaining <- ds[!row.names(ds) %in% row.names(d_tn), ]  # Remaining set
d_ts <- d_remaining[1:n_test, ]  # Test set
d_vd <- d_remaining[(n_test + 1):(n_test + n_validate), ]  # Validation set

d_tn$Diabetes_binary <- as.factor(d_tn$Diabetes_binary)
d_vd$Diabetes_binary <- as.factor(d_vd$Diabetes_binary)



# Update the datasets with selected features
d_tn <- d_tn[, c("Diabetes_binary", selected_features), with = FALSE]
d_vd <- d_vd[, c("Diabetes_binary", selected_features), with = FALSE]
d_ts <- d_ts[, c("Diabetes_binary", selected_features), with = FALSE]

# Hyperparameter tuning using the validation dataset
accuracy_list_nb <- vector("numeric", length = 5)  # Placeholder for storing accuracy values (Naive Bayes)
accuracy_list_lr <- vector("numeric", length = 5)  # Placeholder for storing accuracy values (Logistic Regression)
accuracy_list_knn <- vector("numeric", length = 5)  # Placeholder for storing accuracy values (KNN)
accuracy_list_rf <- vector("numeric", length = 5)  # Placeholder for storing accuracy values (Random Forest)

best_model_nb <- NULL  # Best Naive Bayes model based on validation accuracy
best_model_lr <- NULL  # Best Logistic Regression model based on validation accuracy
best_model_knn <- NULL  # Best KNN model based on validation accuracy
best_model_rf <- NULL  # Best Random Forest model based on validation accuracy


for (i in 1:5) {
  # Train the Naive Bayes classifier using the training dataset
  nb_model <- naiveBayes(Diabetes_binary ~ ., data = d_tn, laplace = i)
  
  # Predict on the validation dataset using the trained classifier
  predictions_nb <- predict(nb_model, newdata = d_vd)
  
  # Evaluate the performance of the classifier on the validation dataset
  conf_matrix_nb <- table(Actual = d_vd$Diabetes_binary, Predicted = predictions_nb)
  accuracy_nb <- sum(diag(conf_matrix_nb)) / sum(conf_matrix_nb)
  accuracy_list_nb[i] <- accuracy_nb
  
  # Check if the current model has higher accuracy than the previous best model
  if (is.null(best_model_nb) || accuracy_nb > best_model_nb$accuracy) {
    best_model_nb <- list(model = nb_model, accuracy = accuracy_nb)
  }
  
  # Train the logistic regression model using the training dataset
  lr_model <- multinom(Diabetes_binary ~ ., data = d_tn , maxit = 50)
  
  # Predict on the validation dataset using the trained model
  predictions_lr <- predict(lr_model, newdata = d_vd, type = "class")
  
  # Evaluate the performance of the model on the validation dataset
  conf_matrix_lr <- table(Actual = d_vd$Diabetes_binary, Predicted = predictions_lr)
  accuracy_lr <- sum(diag(conf_matrix_lr)) / sum(conf_matrix_lr)
  
  # Check if the current model has higher accuracy than the previous best model
  if (is.null(best_model_lr) || accuracy_lr > best_model_lr$accuracy) {
    best_model_lr <- list(model = lr_model, accuracy = accuracy_lr)
  }
  
  # Train the KNN classifier using the training dataset
  knn_model <- knn(train = d_tn[, -1], test = d_vd[, -1], cl = d_tn$Diabetes_binary, k = i)
  
  # Predict on the validation dataset using the trained classifier
  predictions_knn <- knn_model
  
  # Evaluate the performance of the classifier on the validation dataset
  conf_matrix_knn <- table(Actual = d_vd$Diabetes_binary, Predicted = predictions_knn)
  accuracy_knn <- sum(diag(conf_matrix_knn)) / sum(conf_matrix_knn)
  accuracy_list_knn[i] <- accuracy_knn
  
  # Check if the current model has higher accuracy than the previous best model
  if (is.null(best_model_knn) || accuracy_knn > best_model_knn$accuracy) {
    best_model_knn <- list(model = knn_model, accuracy = accuracy_knn)
  }
  
  # Train the Random Forest classifier using the training dataset
  rf_model <- randomForest(Diabetes_binary ~ ., data = d_tn, ntree = 100, importance = TRUE)
  
  # Predict on the validation dataset using the trained classifier
  predictions_rf <- predict(rf_model, newdata = d_vd)
  
  # Evaluate the performance of the classifier on the validation dataset
  conf_matrix_rf <- table(Actual = d_vd$Diabetes_binary, Predicted = predictions_rf)
  accuracy_rf <- sum(diag(conf_matrix_rf)) / sum(conf_matrix_rf)
  accuracy_list_rf[i] <- accuracy_rf
  
  # Check if the current model has higher accuracy than the previous best model
  if (is.null(best_model_rf) || accuracy_rf > best_model_rf$accuracy) {
    best_model_rf <- list(model = rf_model, accuracy = accuracy_rf)
  }
}

# Extract variable importance from the Random Forest model
importance_rf <- importance(best_model_rf$model)

# Select the top 10 most important variables
top_variables <- row.names(importance_rf)[order(importance_rf[, 1], decreasing = TRUE)][1:10]

# Subset the training and validation datasets to include only the top variables
d_tn_top <- d_tn[, c("Diabetes_binary", top_variables)]
d_vd_top <- d_vd[, c("Diabetes_binary", top_variables)]

# Train the final models using the combined training and validation datasets with top variables
final_nb_model <- naiveBayes(Diabetes_binary ~ ., data = d_tn_top)
final_lr_model <- multinom(Diabetes_binary ~ ., data = d_tn_top, maxit = 50)
final_knn_model <- knn(train = d_tn_top[, -1], test = d_vd_top[, -1], cl = d_tn_top$Diabetes_binary, k = 1)
final_rf_model <- randomForest(Diabetes_binary ~ ., data = d_tn_top, ntree = 100, importance = TRUE)

# Predict on the test dataset using the final models with top variables
predictions_nb <- predict(final_nb_model, newdata = d_ts[, top_variables])
predictions_lr <- predict(final_lr_model, newdata = d_ts[, top_variables], type = "class")
predictions_knn <- knn(train = d_tn_top[, -1], test = d_ts[, top_variables], cl = d_tn_top$Diabetes_binary, k = 1)
predictions_rf <- predict(final_rf_model, newdata = d_ts[, top_variables])

# Evaluate the performance of the models on the test dataset
conf_matrix_nb <- table(Actual = d_ts$Diabetes_binary, Predicted = predictions_nb)
accuracy_nb <- sum(diag(conf_matrix_nb)) / sum(conf_matrix_nb)

conf_matrix_lr <- table(Actual = d_ts$Diabetes_binary, Predicted = predictions_lr)
accuracy_lr <- sum(diag(conf_matrix_lr)) / sum(conf_matrix_lr)

conf_matrix_knn <- table(Actual = d_ts$Diabetes_binary, Predicted = predictions_knn)
accuracy_knn <- sum(diag(conf_matrix_knn)) / sum(conf_matrix_knn)

conf_matrix_rf <- table(Actual = d_ts$Diabetes_binary, Predicted = predictions_rf)
accuracy_rf <- sum(diag(conf_matrix_rf)) / sum(conf_matrix_rf)

# Calculate precision, recall, and F1-score
precision_nb <- conf_matrix_nb[2, 2] / sum(conf_matrix_nb[, 2])
recall_nb <- conf_matrix_nb[2, 2] / sum(conf_matrix_nb[2, ])
f1_score_nb <- 2 * (precision_nb * recall_nb) / (precision_nb + recall_nb)

precision_lr <- conf_matrix_lr[2, 2] / sum(conf_matrix_lr[, 2])
recall_lr <- conf_matrix_lr[2, 2] / sum(conf_matrix_lr[2, ])
f1_score_lr <- 2 * (precision_lr * recall_lr) / (precision_lr + recall_lr)

precision_knn <- conf_matrix_knn[2, 2] / sum(conf_matrix_knn[, 2])
recall_knn <- conf_matrix_knn[2, 2] / sum(conf_matrix_knn[2, ])
f1_score_knn <- 2 * (precision_knn * recall_knn) / (precision_knn + recall_knn)

precision_rf <- conf_matrix_rf[2, 2] / sum(conf_matrix_rf[, 2])
recall_rf <- conf_matrix_rf[2, 2] / sum(conf_matrix_rf[2, ])
f1_score_rf <- 2 * (precision_rf * recall_rf) / (precision_rf + recall_rf)

# Print the results
print("Naive Bayes Model:")
print(conf_matrix_nb)
print(paste("Accuracy:", accuracy_nb))
print(paste("Precision:", precision_nb))
print(paste("Recall:", recall_nb))
print(paste("F1-score:", f1_score_nb))

print("Logistic Regression Model:")
print(conf_matrix_lr)
print(paste("Accuracy:", accuracy_lr))
print(paste("Precision:", precision_lr))
print(paste("Recall:", recall_lr))
print(paste("F1-score:", f1_score_lr))

print("K-Nearest Neighbors Model:")
print(conf_matrix_knn)
print(paste("Accuracy:", accuracy_knn))
print(paste("Precision:", precision_knn))
print(paste("Recall:", recall_knn))
print(paste("F1-score:", f1_score_knn))

print("Random Forest Model:")
print(conf_matrix_rf)
print(paste("Accuracy:", accuracy_rf))
print(paste("Precision:", precision_rf))
print(paste("Recall:", recall_rf))
print(paste("F1-score:", f1_score_rf))